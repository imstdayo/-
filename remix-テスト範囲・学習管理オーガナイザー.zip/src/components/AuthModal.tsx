import React, { useState } from 'react';
import { 
  X, 
  Lock, 
  User as UserIcon, 
  LogIn, 
  UserPlus, 
  Eye, 
  EyeOff, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  GraduationCap,
  KeyRound
} from 'lucide-react';
import { 
  loginWithIdAndPassword, 
  registerWithIdAndPassword, 
  googleSignIn 
} from '../lib/classroomAuth';
import { UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (profile: UserProfile, message?: string, token?: string, googleUser?: any) => void;
  currentUserName?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  currentUserName
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  
  // Form fields
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [grade, setGrade] = useState('高校2年生');
  const [targetGoal, setTargetGoal] = useState('定期テストで自己ベスト更新！');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setIsLoading(true);

    try {
      if (mode === 'login') {
        const { profile } = await loginWithIdAndPassword(loginId, password);
        setSuccessMessage(`ログイン完了！Classroomの最新課題・テスト範囲を同時に同期しています...`);
        setTimeout(() => {
          onLoginSuccess(profile, `ログイン & Classroom同期完了: ${profile.name}さん`);
          onClose();
        }, 700);
      } else {
        const { profile } = await registerWithIdAndPassword(
          loginId, 
          password, 
          displayName || loginId, 
          grade, 
          targetGoal
        );
        setSuccessMessage(`アカウント登録完了！Classroomの最新課題・範囲を初期同期中...`);
        setTimeout(() => {
          onLoginSuccess(profile, `アカウント登録 & Classroom同期完了: ${profile.name}さん`);
          onClose();
        }, 700);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'ログインまたは登録に失敗しました');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemoFill = () => {
    setMode('login');
    setLoginId('student01');
    setPassword('password123');
    setErrorMessage(null);
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await googleSignIn();
      if (res?.user) {
        const rawName = res.user.displayName || '生徒';
        const formattedName = rawName.includes('の学習ダッシュボード')
          ? rawName
          : `${rawName}さんの学習ダッシュボード`;

        const googleProfile: UserProfile = {
          id: `user_google_${res.user.uid.slice(0, 8)}`,
          name: formattedName,
          roleTitle: 'Google Classroom連携中',
          avatar: res.user.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
          totalStudyMinutes: 0,
          todayStudyMinutes: 0,
          streakDays: 1,
          targetGoal: '志望校合格・期末テスト対策',
          competitionEnabled: true,
          weeklyPoints: 100,
          totalPoints: 100,
          rankLeague: 'ゴールド'
        };

        setSuccessMessage(`Googleアカウント連携完了！Classroomの授業・課題を同期しています...`);
        setTimeout(() => {
          onLoginSuccess(googleProfile, `Classroom同期ログイン完了: ${rawName}さん`, res.accessToken, res.user);
          onClose();
        }, 700);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Googleログインに失敗しました');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header with gradient banner */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 pt-6 pb-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition"
            aria-label="閉じる"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="w-9 h-9 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center border border-white/20">
              <KeyRound className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight">ID・パスワードでログイン</h2>
              <p className="text-xs text-blue-100">学習データとポイントを安全に同期・保存</p>
            </div>
          </div>

          {/* Mode Tabs */}
          <div className="mt-4 grid grid-cols-2 gap-1 bg-black/20 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
                mode === 'login'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              ログイン
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
                mode === 'register'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-white/80 hover:text-white hover:bg-white/10'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              新規アカウント登録
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6">
          {errorMessage && (
            <div className="mb-4 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div className="font-medium leading-relaxed">{errorMessage}</div>
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-700 flex items-start gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              <div className="font-bold">{successMessage}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Login ID field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ログインID <span className="text-slate-400 font-normal">（またはメールアドレス）</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={loginId}
                  onChange={e => setLoginId(e.target.value)}
                  placeholder={mode === 'login' ? "例: student01 または メールアドレス" : "半角英数 (例: taro123)"}
                  className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                />
              </div>
            </div>

            {/* Additional Fields for Registration */}
            {mode === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    お名前 <span className="text-slate-400 font-normal">（ニックネーム可）</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    placeholder="例: 山田 太郎"
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">学年・区分</label>
                    <select
                      value={grade}
                      onChange={e => setGrade(e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
                    >
                      <option value="高校1年生">高校1年生</option>
                      <option value="高校2年生">高校2年生</option>
                      <option value="高校3年生">高校3年生</option>
                      <option value="中学1年生">中学1年生</option>
                      <option value="中学2年生">中学2年生</option>
                      <option value="中学3年生">中学3年生</option>
                      <option value="大学受験・浪人生">大学受験・浪人生</option>
                      <option value="資格学習・その他">資格学習・その他</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">学習目標・志望校</label>
                    <input
                      type="text"
                      value={targetGoal}
                      onChange={e => setTargetGoal(e.target.value)}
                      placeholder="例: 期末テスト80点以上"
                      className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
                    />
                  </div>
                </div>
              </>
            )}

            {/* Password field */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">
                  パスワード
                  {mode === 'register' && <span className="text-slate-400 font-normal ml-1">（6文字以上）</span>}
                </label>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 transition"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Classroom Simultaneous Sync Indicator */}
            <div className="p-2.5 rounded-xl bg-blue-50/80 border border-blue-200/80 text-[11px] text-blue-800 flex items-center gap-2">
              <div className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 leading-tight">
                <span className="font-bold">Google Classroom同時同期</span>
                <span className="text-blue-600 ml-1">（ログインと同時に最新課題とテスト範囲を反映）</span>
              </div>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md transition transform active:scale-[0.99] disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : mode === 'login' ? (
                <>
                  <LogIn className="w-4 h-4" />
                  IDでログイン & Classroom同期
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  アカウント作成 & Classroom同期
                </>
              )}
            </button>
          </form>

          {/* Quick Demo ID helper button */}
          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={handleQuickDemoFill}
              className="text-[11px] font-bold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              お試しデモIDをワンクリック自動入力
            </button>

            <span className="text-[10px] text-slate-400">
              {currentUserName ? `現在: ${currentUserName}` : ''}
            </span>
          </div>

          {/* Divider */}
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-white px-2 text-slate-400 text-[11px]">または</span>
            </div>
          </div>

          {/* Google Classroom Sign-In alternative */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full py-2.5 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition flex items-center justify-center gap-2 shadow-2xs"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.36 24 12 24Z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15Z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z"
              />
            </svg>
            <span>Googleアカウントでログイン（Classroom連携）</span>
          </button>
        </div>
      </div>
    </div>
  );
};
